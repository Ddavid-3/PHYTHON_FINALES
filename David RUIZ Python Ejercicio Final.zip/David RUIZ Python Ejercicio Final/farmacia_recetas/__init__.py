# farmacia_recetas/__init__.py

from . import models