# farmacia_recetas/__manifest__.py

{
    'name': 'Farmacia Saludable - Gestión de Recetas Médicas',
    'version': '16.0.1.0.0',
    'category': 'Healthcare/Pharmacy',
    'summary': 'Gestión de recetas médicas para farmacias',
    'description': """
        Módulo personalizado para la gestión de recetas médicas en una farmacia.
        
        Características principales:
        - Registro de recetas médicas por paciente
        - Control de medicamentos prescritos
        - Seguimiento de entregas y caducidad
        - Cálculo automático del total de la receta
        - Gestión de obra social y copagos
        - Flujo completo: Borrador → Confirmada → En Preparación → Entregada → Facturada
        - Control de vencimiento de recetas
        
        Ideal para farmacias que necesitan tracking de prescripciones médicas.
    """,
    'author': 'Farmacia Saludable S.L.',
    'website': 'https://www.farmaciasaludable.com',
    'depends': ['base', 'mail', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'data/farmacia_receta_data.xml',
        'views/farmacia_receta_views.xml',
        'views/farmacia_receta_menus.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}