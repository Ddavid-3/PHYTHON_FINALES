# farmacia_recetas/models/__init__.py

from . import farmacia_receta