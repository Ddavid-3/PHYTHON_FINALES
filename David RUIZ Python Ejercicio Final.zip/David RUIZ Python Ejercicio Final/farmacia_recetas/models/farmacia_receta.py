# farmacia_recetas/models/farmacia_receta.py

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import timedelta, date


class FarmaciaReceta(models.Model):
    """
    Modelo principal para la gestión de recetas médicas en farmacia.
    Gestiona el ciclo de vida completo de una receta.
    """
    _name = 'farmacia.receta'
    _description = 'Receta Médica'
    _rec_name = 'numero_receta'
    _order = 'fecha_emision DESC, prioridad DESC'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    # ==================== 1. CAMPOS BÁSICOS ====================
    
    # Campo Char - Número de receta
    numero_receta = fields.Char(
        string='Nº Receta',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('Nueva'),
        tracking=True
    )
    
    # Campo Char - Nombre del médico
    medico_nombre = fields.Char(
        string='Médico',
        required=True,
        tracking=True,
        help='Nombre del médico que prescribe'
    )
    
    # Campo Char - Matrícula profesional
    medico_matricula = fields.Char(
        string='Matrícula Profesional',
        tracking=True
    )
    
    # Campo Text - Diagnóstico
    diagnostico = fields.Text(
        string='Diagnóstico',
        help='Descripción del diagnóstico médico'
    )
    
    # Campo Text - Observaciones
    observaciones = fields.Text(
        string='Observaciones',
        help='Observaciones adicionales para el farmacéutico'
    )
    
    # Campo Date - Fecha de emisión
    fecha_emision = fields.Date(
        string='Fecha de Emisión',
        required=True,
        default=fields.Date.today,
        tracking=True
    )
    
    # Campo Date - Fecha de vencimiento
    fecha_vencimiento = fields.Date(
        string='Fecha de Vencimiento',
        compute='_compute_fecha_vencimiento',
        store=True,
        help='La receta vence a los 30 días de la emisión'
    )
    
    # Campo Float - Subtotal
    subtotal = fields.Float(
        string='Subtotal (€)',
        compute='_compute_totales',
        store=True,
        help='Suma de los precios de los medicamentos'
    )
    
    # Campo Float - Total con copago
    total_copago = fields.Float(
        string='Total con Copago (€)',
        compute='_compute_totales',
        store=True,
        help='Subtotal - cobertura de obra social'
    )
    
    # Campo Integer - Cantidad de medicamentos
    cantidad_medicamentos = fields.Integer(
        string='Cantidad de Medicamentos',
        compute='_compute_cantidad_medicamentos',
        store=True,
        help='Número de medicamentos en la receta'
    )
    
    # ==================== 2. CAMPO SELECTION ====================
    
    prioridad = fields.Selection(
        selection=[
            ('urgente', '🔴 Urgente - 24h'),
            ('alta', '🟠 Alta - 48h'),
            ('normal', '🟡 Normal - 72h'),
            ('baja', '🟢 Baja - 5 días'),
        ],
        string='Prioridad',
        default='normal',
        required=True,
        tracking=True
    )
    
    obra_social = fields.Selection(
        selection=[
            ('pami', 'PAMI'),
            ('osde', 'OSDE'),
            ('swiss', 'Swiss Medical'),
            ('galeno', 'Galeno'),
            ('medicus', 'Medicus'),
            ('particular', 'Particular'),
            ('otra', 'Otra Obra Social'),
        ],
        string='Obra Social',
        required=True,
        default='particular',
        tracking=True
    )
    
    tipo_receta = fields.Selection(
        selection=[
            ('comun', 'Receta Común'),
            ('psicotropicos', 'Psicotrópicos'),
            ('antibioticos', 'Antibióticos'),
            ('cronica', 'Tratamiento Crónico'),
            ('duplicado', 'Receta Duplicado'),
        ],
        string='Tipo de Receta',
        required=True,
        default='comun',
        tracking=True
    )
    
    # ==================== 3. CAMPO STATE (FLUJO DE ESTADOS) ====================
    
    state = fields.Selection(
        selection=[
            ('borrador', '📝 Borrador'),
            ('confirmada', '✅ Confirmada'),
            ('preparacion', '⚕️ En Preparación'),
            ('entregada', '📦 Entregada'),
            ('facturada', '💰 Facturada'),
            ('vencida', '⏰ Vencida'),
            ('cancelada', '❌ Cancelada'),
        ],
        string='Estado',
        default='borrador',
        required=True,
        tracking=True,
        copy=False
    )
    
    # ==================== 4. CAMPOS RELACIONALES ====================
    
    # Paciente (cliente)
    paciente_id = fields.Many2one(
        'res.partner',
        string='Paciente',
        required=True,
        tracking=True,
        help='Paciente al que se le prescribe la medicación',
        domain=[('is_company', '=', False)]
    )
    
    # Farmacéutico responsable
    farmaceutico_id = fields.Many2one(
        'res.users',
        string='Farmacéutico Responsable',
        tracking=True,
        help='Farmacéutico que prepara y entrega la receta'
    )
    
    # Medicamentos (líneas de receta)
    lineas_ids = fields.One2many(
        'farmacia.receta.linea',
        'receta_id',
        string='Medicamentos',
        tracking=True
    )
    
    # ==================== 5. CAMPOS CALCULADOS (@api.depends) ====================
    
    @api.depends('fecha_emision')
    def _compute_fecha_vencimiento(self):
        """La receta vence a los 30 días de la emisión (por defecto)"""
        for receta in self:
            if receta.fecha_emision:
                receta.fecha_vencimiento = receta.fecha_emision + timedelta(days=30)
            else:
                receta.fecha_vencimiento = False
    
    @api.depends('lineas_ids', 'lineas_ids.subtotal_linea')
    def _compute_totales(self):
        """Calcula el subtotal y el total con copago"""
        for receta in self:
            subtotal = sum(receta.lineas_ids.mapped('subtotal_linea'))
            receta.subtotal = subtotal
            
            # Calcular copago según obra social
            porcentaje_copago = self._get_porcentaje_copago(receta.obra_social)
            total_copago = subtotal * (porcentaje_copago / 100)
            receta.total_copago = total_copago
    
    @api.depends('lineas_ids')
    def _compute_cantidad_medicamentos(self):
        """Calcula la cantidad de medicamentos en la receta"""
        for receta in self:
            receta.cantidad_medicamentos = len(receta.lineas_ids)
    
    def _get_porcentaje_copago(self, obra_social):
        """Retorna el porcentaje de copago según la obra social"""
        porcentajes = {
            'pami': 0,      # 0% copago
            'osde': 30,     # 70% cubre OSDE
            'swiss': 35,    # 65% cubre Swiss
            'galeno': 40,   # 60% cubre Galeno
            'medicus': 25,  # 75% cubre Medicus
            'particular': 100,  # 100% paga el paciente
            'otra': 50,     # 50% genérico
        }
        return porcentajes.get(obra_social, 100)
    
    # Campo adicional - días para vencer
    dias_para_vencer = fields.Integer(
        string='Días para vencer',
        compute='_compute_dias_para_vencer',
        store=True,
        help='Días restantes antes del vencimiento'
    )
    
    esta_vencida = fields.Boolean(
        string='¿Vencida?',
        compute='_compute_esta_vencida',
        store=True,
        help='Indica si la receta está vencida'
    )
    
    @api.depends('fecha_vencimiento', 'state')
    def _compute_dias_para_vencer(self):
        """Calcula los días restantes para el vencimiento"""
        for receta in receta:
            if receta.fecha_vencimiento and receta.state not in ['vencida', 'cancelada', 'entregada']:
                hoy = date.today()
                dias = (receta.fecha_vencimiento - hoy).days
                receta.dias_para_vencer = max(0, dias)
            else:
                receta.dias_para_vencer = 0
    
    @api.depends('fecha_vencimiento', 'state')
    def _compute_esta_vencida(self):
        """Determina si la receta está vencida"""
        for receta in receta:
            if (receta.fecha_vencimiento and 
                receta.state not in ['entregada', 'facturada', 'cancelada'] and
                date.today() > receta.fecha_vencimiento):
                receta.esta_vencida = True
            else:
                receta.esta_vencida = False
    
    # ==================== 6. MÉTODOS PARA CAMBIAR ESTADO ====================
    
    def action_confirmar(self):
        """Cambia estado a 'Confirmada'"""
        for receta in self:
            if not receta.lineas_ids:
                raise ValidationError(_('Debe agregar al menos un medicamento a la receta.'))
            
            if receta.numero_receta == _('Nueva'):
                receta.numero_receta = self._generate_numero_receta()
            
            receta.state = 'confirmada'
            receta.message_post(
                body=f'Receta confirmada para el paciente {receta.paciente_id.name}',
                subject='Receta Confirmada'
            )
        return True
    
    def action_iniciar_preparacion(self):
        """Cambia estado a 'En Preparación'"""
        self.state = 'preparacion'
        self.message_post(
            body='Se ha iniciado la preparación de los medicamentos',
            subject='Preparación Iniciada'
        )
        return True
    
    def action_entregar(self):
        """Cambia estado a 'Entregada'"""
        for receta in self:
            if not receta.farmaceutico_id:
                raise ValidationError(_('Debe asignar un farmacéutico responsable.'))
            
            receta.state = 'entregada'
            receta.message_post(
                body=f'Medicamentos entregados por {receta.farmaceutico_id.name}',
                subject='Receta Entregada'
            )
        return True
    
    def action_facturar(self):
        """Cambia estado a 'Facturada'"""
        self.state = 'facturada'
        self.message_post(
            body=f'Total facturado: ${self.total_copago:.2f}',
            subject='Receta Facturada'
        )
        return True
    
    def action_cancelar(self):
        """Cambia estado a 'Cancelada'"""
        self.state = 'cancelada'
        self.message_post(
            body='Receta cancelada',
            subject='Receta Cancelada'
        )
        return True
    
    def action_marcar_vencida(self):
        """Marca la receta como vencida"""
        self.state = 'vencida'
        self.message_post(
            body='Receta marcada como vencida',
            subject='Receta Vencida'
        )
        return True
    
    # ==================== 7. MÉTODO PROPIO ADICIONAL ====================
    
    def calcular_prioridad_segun_vencimiento(self):
        """
        Método propio que calcula la prioridad automáticamente
        basándose en los días para vencer.
        """
        for receta in self:
            if receta.dias_para_vencer <= 3:
                receta.prioridad = 'urgente'
            elif receta.dias_para_vencer <= 7:
                receta.prioridad = 'alta'
            elif receta.dias_para_vencer <= 15:
                receta.prioridad = 'normal'
            else:
                receta.prioridad = 'baja'
            
            receta.message_post(
                body=f'Prioridad actualizada automáticamente: {receta.prioridad}',
                subject='Prioridad Actualizada'
            )
        return True
    
    def enviar_recordatorio_paciente(self):
        """
        Envía un recordatorio al paciente sobre su receta.
        """
        for receta in self:
            # Simulación de envío de email/notificación
            mensaje = f"""
            Recordatorio: Su receta N° {receta.numero_receta} 
            está {'próxima a vencer' if receta.dias_para_vencer <= 5 else 'disponible'}.
            Días para vencer: {receta.dias_para_vencer}
            """
            receta.message_post(
                body=mensaje,
                subject='Recordatorio de Receta'
            )
        return True
    
    def _generate_numero_receta(self):
        """Genera un número único para la receta"""
        last = self.search([], order='id desc', limit=1)
        if last and last.numero_receta and last.numero_receta != _('Nueva'):
            try:
                num = int(last.numero_receta.split('-')[1]) + 1
            except (IndexError, ValueError):
                num = 1
        else:
            num = 1
        año_actual = date.today().year
        return f'RX-{año_actual}-{num:06d}'
    
    # ==================== 8. VALIDACIONES ====================
    
    @api.constrains('fecha_emision', 'fecha_vencimiento')
    def _check_fechas(self):
        """Valida que la fecha de emisión no sea posterior al vencimiento"""
        for receta in self:
            if receta.fecha_vencimiento and receta.fecha_emision:
                if receta.fecha_vencimiento < receta.fecha_emision:
                    raise ValidationError(_('La fecha de vencimiento no puede ser anterior a la fecha de emisión.'))
    
    # ==================== 9. SOBRESCRITURA DE CREATE ====================
    
    @api.model_create_multi
    def create(self, vals_list):
        """Sobrescribe create para generar número de receta automático"""
        for vals in vals_list:
            if vals.get('numero_receta', _('Nueva')) == _('Nueva'):
                vals['numero_receta'] = self._generate_numero_receta()
        return super().create(vals_list)
    
    # ==================== 10. ACCIONES DE CRON ====================
    
    def _cron_marcar_recetas_vencidas(self):
        """Acción programada para marcar recetas vencidas automáticamente"""
        recetas_a_vencer = self.search([
            ('state', 'in', ['confirmada', 'preparacion']),
            ('esta_vencida', '=', True)
        ])
        recetas_a_vencer.action_marcar_vencida()
        return True


class FarmaciaRecetaLinea(models.Model):
    """
    Línea de receta: medicamentos prescritos
    """
    _name = 'farmacia.receta.linea'
    _description = 'Línea de Receta'
    _rec_name = 'medicamento_nombre'
    
    # Relación con la receta principal
    receta_id = fields.Many2one(
        'farmacia.receta',
        string='Receta',
        required=True,
        ondelete='cascade'
    )
    
    # Campo Char - Nombre del medicamento
    medicamento_nombre = fields.Char(
        string='Medicamento',
        required=True
    )
    
    # Campo Text - Indicaciones
    indicaciones = fields.Text(
        string='Indicaciones',
        help='Modo de uso y recomendaciones'
    )
    
    # Campo Float - Cantidad
    cantidad = fields.Float(
        string='Cantidad',
        required=True,
        default=1.0,
        help='Cantidad de unidades'
    )
    
    # Campo Float - Precio unitario
    precio_unitario = fields.Float(
        string='Precio Unitario (€)',
        required=True,
        default=0.0
    )
    
    # Campo calculado - Subtotal línea
    subtotal_linea = fields.Float(
        string='Subtotal (€)',
        compute='_compute_subtotal_linea',
        store=True
    )
    
    # Campo Selection - Forma farmacéutica
    forma_farmaceutica = fields.Selection(
        selection=[
            ('comprimido', 'Comprimido'),
            ('capsula', 'Cápsula'),
            ('jarabe', 'Jarabe'),
            ('crema', 'Crema'),
            ('inyectable', 'Inyectable'),
            ('inhalador', 'Inhalador'),
            ('gotas', 'Gotas'),
        ],
        string='Forma Farmacéutica',
        required=True,
        default='comprimido'
    )
    
    # Campo Selection - Frecuencia
    frecuencia = fields.Selection(
        selection=[
            ('cada_8h', 'Cada 8 horas'),
            ('cada_12h', 'Cada 12 horas'),
            ('cada_24h', 'Cada 24 horas'),
            ('diario', 'Una vez al día'),
            ('semanal', 'Semanal'),
            ('bajo_demanda', 'Bajo demanda'),
        ],
        string='Frecuencia',
        required=True,
        default='cada_8h'
    )
    
    # Duración del tratamiento
    duracion_dias = fields.Integer(
        string='Duración (días)',
        default=7,
        help='Días que dura el tratamiento'
    )
    
    @api.depends('cantidad', 'precio_unitario')
    def _compute_subtotal_linea(self):
        """Calcula el subtotal de la línea"""
        for linea in self:
            linea.subtotal_linea = linea.cantidad * linea.precio_unitario