
import subprocess
import sys
from typing import Optional


# Colores ANSI para salida
class Colores:
    """Códigos de color ANSI para terminal."""
    VERDE = '\033[92m'
    ROJO = '\033[91m'
    AMARILLO = '\033[93m'
    AZUL = '\033[94m'
    RESET = '\033[0m'


def ejecutar_comando(comando: list[str], descripcion: str) -> subprocess.CompletedProcess:
    """
    Ejecuta un comando del sistema y maneja la salida con colores.
    
    Args:
        comando: Lista con el comando y sus argumentos
        descripcion: Descripción de la operación para mostrar
    
    Returns:
        CompletedProcess con el resultado de la ejecución
    """
    print(f"{Colores.AZUL}▶ {descripcion}{Colores.RESET}")
    
    try:
        resultado = subprocess.run(
            comando,
            capture_output=True,
            text=True,
            check=False
        )
        
        if resultado.returncode == 0:
            if resultado.stdout:
                print(f"{Colores.VERDE}{resultado.stdout}{Colores.RESET}", end="")
            else:
                print(f"{Colores.VERDE}✓ Operación exitosa{Colores.RESET}")
        else:
            print(f"{Colores.ROJO}✗ Error: {resultado.stderr}{Colores.RESET}", end="")
        
        return resultado
        
    except FileNotFoundError:
        print(f"{Colores.ROJO}✗ Comando no encontrado. ¿Está instalado?{Colores.RESET}")
        return subprocess.CompletedProcess(comando, returncode=1, stdout="", stderr="")
    except Exception as e:
        print(f"{Colores.ROJO}✗ Error inesperado: {e}{Colores.RESET}")
        return subprocess.CompletedProcess(comando, returncode=1, stdout="", stderr=str(e))


def listar_directorio(ruta: str) -> subprocess.CompletedProcess:
    """
    Lista el contenido de un directorio (comando dir/ls).
    
    Args:
        ruta: Ruta del directorio a listar
    """
    if sys.platform == "win32":
        comando = ["dir", ruta]
    else:
        comando = ["ls", "-la", ruta]
    
    return ejecutar_comando(comando, f"Listando directorio: {ruta}")


def copiar_archivo(origen: str, destino: str) -> subprocess.CompletedProcess:
    """
    Copia un archivo a una ubicación de destino (comando copy/cp).
    
    Args:
        origen: Ruta del archivo a copiar
        destino: Ruta de destino (carpeta o archivo)
    """
    if sys.platform == "win32":
        comando = ["copy", origen, destino]
    else:
        comando = ["cp", origen, destino]
    
    return ejecutar_comando(comando, f"Copiando {origen} → {destino}")


def eliminar_archivo(ruta: str) -> subprocess.CompletedProcess:
    """
    Elimina un archivo (comando del/rm).
    
    Args:
        ruta: Ruta del archivo a eliminar
    """
    if sys.platform == "win32":
        comando = ["del", ruta]
    else:
        comando = ["rm", ruta]
    
    return ejecutar_comando(comando, f"Eliminando archivo: {ruta}")


def crear_directorio(ruta: str) -> subprocess.CompletedProcess:
    """
    Crea un nuevo directorio (comando md/mkdir).
    
    Args:
        ruta: Ruta del directorio a crear
    """
    if sys.platform == "win32":
        comando = ["mkdir", ruta]
    else:
        comando = ["mkdir", "-p", ruta]
    
    return ejecutar_comando(comando, f"Creando directorio: {ruta}")


def eliminar_directorio(ruta: str, recursivo: bool = False) -> subprocess.CompletedProcess:
    """
    Elimina un directorio (comando rd/rmdir).
    
    Args:
        ruta: Ruta del directorio a eliminar
        recursivo: Si es True, elimina directorios no vacíos
    """
    if sys.platform == "win32":
        if recursivo:
            comando = ["rmdir", "/s", "/q", ruta]
        else:
            comando = ["rmdir", ruta]
    else:
        if recursivo:
            comando = ["rm", "-rf", ruta]
        else:
            comando = ["rmdir", ruta]
    
    descripcion = f"Eliminando directorio (recursivo={recursivo}): {ruta}"
    return ejecutar_comando(comando, descripcion)


def mostrar_ayuda() -> None:
    """Muestra la ayuda de los comandos disponibles."""
    ayuda = f"""
{Colores.AZUL}=== SISTEMA - Comandos disponibles ==={Colores.RESET}

{Colores.VERDE}ls/dir   <ruta>{Colores.RESET}     - Lista contenido del directorio
{Colores.VERDE}cp/copy  <origen> <destino>{Colores.RESET} - Copia archivo
{Colores.VERDE}rm/del   <ruta>{Colores.RESET}     - Elimina archivo
{Colores.VERDE}mkdir/md <ruta>{Colores.RESET}     - Crea directorio
{Colores.VERDE}rmdir/rd <ruta>{Colores.RESET}     - Elimina directorio vacío
{Colores.VERDE}rmdir -r <ruta>{Colores.RESET}     - Elimina directorio (recursivo)

{Colores.AMARILLO}Nota: Los comandos se adaptan automáticamente a Windows/GNU/Linux{Colores.RESET}
"""
    print(ayuda)


def menu_interactivo() -> None:
    """
    Menú interactivo para probar las funciones del módulo.
    """
    while True:
        print(f"\n{Colores.AZUL}=== MENÚ DEL SISTEMA ==={Colores.RESET}")
        print("1. Listar directorio")
        print("2. Copiar archivo")
        print("3. Eliminar archivo")
        print("4. Crear directorio")
        print("5. Eliminar directorio")
        print("6. Eliminar directorio (recursivo)")
        print("7. Ayuda")
        print("0. Salir")
        
        opcion = input("\nSeleccione una opción: ")
        
        if opcion == "0":
            print(f"{Colores.VERDE}¡Hasta luego!{Colores.RESET}")
            break
        elif opcion == "1":
            ruta = input("Ruta del directorio: ")
            listar_directorio(ruta)
        elif opcion == "2":
            origen = input("Archivo origen: ")
            destino = input("Destino: ")
            copiar_archivo(origen, destino)
        elif opcion == "3":
            ruta = input("Archivo a eliminar: ")
            eliminar_archivo(ruta)
        elif opcion == "4":
            ruta = input("Directorio a crear: ")
            crear_directorio(ruta)
        elif opcion == "5":
            ruta = input("Directorio a eliminar: ")
            eliminar_directorio(ruta, recursivo=False)
        elif opcion == "6":
            ruta = input("Directorio a eliminar (recursivo): ")
            eliminar_directorio(ruta, recursivo=True)
        elif opcion == "7":
            mostrar_ayuda()
        else:
            print(f"{Colores.ROJO}Opción no válida{Colores.RESET}")


if __name__ == "__main__":
    # Si se ejecuta directamente, mostrar ayuda
    if len(sys.argv) > 1:
        # Modo comando directo
        comando = sys.argv[1].lower()
        if comando in ["ls", "dir"] and len(sys.argv) > 2:
            listar_directorio(sys.argv[2])
        elif comando in ["cp", "copy"] and len(sys.argv) > 3:
            copiar_archivo(sys.argv[2], sys.argv[3])
        elif comando in ["rm", "del"] and len(sys.argv) > 2:
            eliminar_archivo(sys.argv[2])
        elif comando in ["mkdir", "md"] and len(sys.argv) > 2:
            crear_directorio(sys.argv[2])
        elif comando in ["rmdir", "rd"] and len(sys.argv) > 2:
            recursivo = "-r" in sys.argv or "--recursive" in sys.argv
            eliminar_directorio(sys.argv[-1], recursivo=recursivo)
        else:
            mostrar_ayuda()
    else:
        # Modo interactivo
        menu_interactivo()