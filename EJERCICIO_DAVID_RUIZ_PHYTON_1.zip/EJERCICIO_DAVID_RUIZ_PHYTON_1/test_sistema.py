

import sistema

def main() -> None:
    """
    Prueba las funciones del módulo sistema.
    """
    print("=== PRUEBAS DEL MÓDULO SISTEMA ===\n")
    
    # Crear directorio de prueba
    sistema.crear_directorio("./test_sistema_temp")
    
    # Listar directorio actual
    sistema.listar_directorio(".")
    
    # Crear archivo de prueba
    with open("./test_sistema_temp/archivo_test.txt", "w") as f:
        f.write("Contenido de prueba")
    
    # Listar el nuevo directorio
    sistema.listar_directorio("./test_sistema_temp")
    
    # Copiar archivo
    sistema.copiar_archivo("./test_sistema_temp/archivo_test.txt", "./test_sistema_temp/copia_test.txt")
    
    # Eliminar archivo original
    sistema.eliminar_archivo("./test_sistema_temp/archivo_test.txt")
    
    # Eliminar directorio recursivamente
    sistema.eliminar_directorio("./test_sistema_temp", recursivo=True)
    
    print("\n✓ Todas las pruebas completadas")


if __name__ == "__main__":
    main()