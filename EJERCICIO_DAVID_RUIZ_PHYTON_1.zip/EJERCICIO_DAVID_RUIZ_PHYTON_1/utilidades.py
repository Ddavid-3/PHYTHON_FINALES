
# Constantes predefinidas
IVA_GENERAL: float = 21.0
IVA_REDUCIDO: float = 10.0
IVA_SUPERREDUCIDO: float = 4.0

DESCUENTO_CANTIDAD: float = 10.0  # 10% descuento por cantidad
UMBRAL_DESCUENTO: float = 1000.00


def calcular_iva(base_imponible: float, iva_porcentaje: float = IVA_GENERAL) -> float:
    """
    Calcula el importe del IVA a partir de la base imponible.
    
    Args:
        base_imponible: Importe base sin IVA
        iva_porcentaje: Porcentaje de IVA (por defecto 21%)
    
    Returns:
        Importe del IVA calculado
    """
    return base_imponible * (iva_porcentaje / 100)


def calcular_total_con_iva(base_imponible: float, iva_porcentaje: float = IVA_GENERAL) -> float:
    """
    Calcula el total de la factura con IVA incluido.
    
    Args:
        base_imponible: Importe base sin IVA
        iva_porcentaje: Porcentaje de IVA (por defecto 21%)
    
    Returns:
        Total con IVA incluido
    """
    return base_imponible + calcular_iva(base_imponible, iva_porcentaje)


def aplicar_descuento(importe: float, porcentaje_descuento: float) -> float:
    """
    Aplica un descuento porcentual a un importe.
    
    Args:
        importe: Importe original
        porcentaje_descuento: Porcentaje de descuento a aplicar
    
    Returns:
        Importe con descuento aplicado
    """
    if porcentaje_descuento < 0 or porcentaje_descuento > 100:
        raise ValueError("El porcentaje de descuento debe estar entre 0 y 100")
    
    descuento: float = importe * (porcentaje_descuento / 100)
    return importe - descuento


def aplicar_descuento_por_cantidad(importe: float, umbral: float = UMBRAL_DESCUENTO, 
                                   descuento: float = DESCUENTO_CANTIDAD) -> tuple[float, bool]:
    """
    Aplica descuento automático si el importe supera el umbral.
    
    Args:
        importe: Importe a evaluar
        umbral: Importe mínimo para aplicar descuento
        descuento: Porcentaje de descuento a aplicar
    
    Returns:
        Tupla con (importe_final, si_se_aplico_descuento)
    """
    if importe > umbral:
        importe_final = aplicar_descuento(importe, descuento)
        return importe_final, True
    return importe, False


def formatear_euros(importe: float) -> str:
    """
    Formatea un importe en euros con dos decimales.
    
    Args:
        importe: Importe a formatear
    
    Returns:
        String formateado (ej: "1.234,56 €")
    """
    return f"{importe:.2f} €"