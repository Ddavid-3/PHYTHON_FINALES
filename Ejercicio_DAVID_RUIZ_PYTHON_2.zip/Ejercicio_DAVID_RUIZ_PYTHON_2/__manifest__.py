{
    'name': 'Sale Order Total with Tax',
    'version': '16.0.1.0.0',
    'category': 'Sales',
    'summary': 'Añade campo calculado de total con IVA en pedidos',
    'description': """
        Módulo personalizado que añade un campo calculado 'amount_total_with_tax'
        al modelo sale.order, mostrando el total del pedido con IVA incluido.
    """,
    'author': 'Empresa',
    'depends': ['sale'],
    'data': [
        'views/sale_order_view.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
