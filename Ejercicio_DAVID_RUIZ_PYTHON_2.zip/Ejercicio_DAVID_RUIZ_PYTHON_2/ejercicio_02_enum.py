

from enum import Enum, auto
from typing import Optional


class EstadoPedido(Enum):
    """
    Enumeración que representa los posibles estados de un pedido.
    """
    BORRADOR = auto()      # Primer estado, valor automático 1
    CONFIRMADO = auto()    # Valor automático 2
    ENVIADO = auto()       # Valor automático 3
    FACTURADO = auto()     # Valor automático 4
    
    def __str__(self) -> str:
        """Representación en string del estado."""
        return self.name


class Pedido:
    """
    Clase que representa un pedido con su estado actual.
    """
    
    def __init__(self, nombre_cliente: str, estado_inicial: EstadoPedido = EstadoPedido.BORRADOR):
        """
        Inicializa un nuevo pedido.
        
        Args:
            nombre_cliente: Nombre del cliente
            estado_inicial: Estado inicial del pedido (por defecto BORRADOR)
        """
        self.nombre_cliente: str = nombre_cliente
        self.estado: EstadoPedido = estado_inicial
    
    def cambiar_estado(self, nuevo_estado: EstadoPedido) -> None:
        """
        Cambia el estado del pedido.
        
        Args:
            nuevo_estado: Nuevo estado a establecer
        """
        estado_anterior = self.estado
        self.estado = nuevo_estado
        print(f"Pedido de {self.nombre_cliente}: {estado_anterior} → {nuevo_estado}")
    
    def __str__(self) -> str:
        """Representación del pedido."""
        return f"Pedido(cliente='{self.nombre_cliente}', estado={self.estado})"


def cambiar_estado_pedido(nuevo_estado: EstadoPedido) -> None:
    """
    Función que simula el cambio de estado de un pedido (versión simplificada).
    
    Args:
        nuevo_estado: Nuevo estado a establecer
    """
    # Estado global simulado (para demostración)
    estado_actual = EstadoPedido.BORRADOR
    
    print(f"Estado actual del pedido: {estado_actual}")
    
    # Realizar el cambio
    estado_actual = nuevo_estado
    
    print(f"Estado actual del pedido: {estado_actual}")


def main() -> None:
    """
    Función principal que demuestra el uso del Enum EstadoPedido.
    """
    print("=== DEMOSTRACIÓN 1: Función simple ===\n")
    
    # Usar la función con un solo argumento (como pide el enunciado)
    cambiar_estado_pedido(EstadoPedido.CONFIRMADO)
    
    print("\n=== DEMOSTRACIÓN 2: Clase Pedido completa ===\n")
    
    # Crear un pedido
    pedido = Pedido("Empresa ABC")
    print(f"Pedido creado: {pedido}")
    
    # Simular el flujo normal de un pedido
    print("\n--- Flujo normal del pedido ---")
    pedido.cambiar_estado(EstadoPedido.CONFIRMADO)
    pedido.cambiar_estado(EstadoPedido.ENVIADO)
    pedido.cambiar_estado(EstadoPedido.FACTURADO)
    
    print("\n=== DEMOSTRACIÓN 3: Transiciones válidas ===\n")
    
    # Mostrar todos los estados posibles
    print("Estados posibles del pedido:")
    for estado in EstadoPedido:
        print(f"  • {estado.name} (valor: {estado.value})")
    
    # Verificar tipos
    print(f"\n¿Es CONFIRMADO un EstadoPedido? {isinstance(EstadoPedido.CONFIRMADO, EstadoPedido)}")


if __name__ == "__main__":
    main()