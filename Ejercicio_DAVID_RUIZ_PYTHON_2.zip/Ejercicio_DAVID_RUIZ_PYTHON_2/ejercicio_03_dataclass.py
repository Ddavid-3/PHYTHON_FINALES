

from dataclasses import dataclass
from typing import List


@dataclass
class Cliente:
    """
    Dataclass que representa un cliente de la empresa.
    
    Atributos:
        nombre: Nombre del cliente (persona o empresa)
        email: Dirección de correo electrónico
        pais: País donde se encuentra el cliente
        activo: Estado del cliente (True = activo, False = inactivo)
    """
    nombre: str
    email: str
    pais: str
    activo: bool = True  # Por defecto, los clientes están activos
    
    def __str__(self) -> str:
        """Representación en string del cliente."""
        return f"Cliente(nombre='{self.nombre}', email='{self.email}', país='{self.pais}', activo={self.activo})"


def main() -> None:
    """
    Función principal que crea y muestra clientes.
    """
    print("=== CREACIÓN DE CLIENTES ===\n")
    
    # Crear dos clientes
    cliente1 = Cliente(
        nombre="Empresa X",
        email="info@x.com",
        pais="España",
        activo=True
    )
    
    cliente2 = Cliente(
        nombre="Tech Solutions S.L.",
        email="contacto@techsolutions.es",
        pais="España"
        # activo toma el valor por defecto (True)
    )
    
    cliente3 = Cliente(
        nombre="Global Trading Inc.",
        email="ventas@globaltrading.com",
        pais="Estados Unidos",
        activo=False
    )
    
    # Mostrar los clientes
    print("Cliente 1:")
    print(cliente1)
    
    print("\nCliente 2 (con activo por defecto):")
    print(cliente2)
    
    print("\nCliente 3:")
    print(cliente3)
    
    # Demostrar acceso a atributos
    print("\n--- Acceso a atributos individuales ---")
    print(f"Nombre del cliente 1: {cliente1.nombre}")
    print(f"Email del cliente 1: {cliente1.email}")
    print(f"País del cliente 1: {cliente1.pais}")
    print(f"¿Está activo? {cliente1.activo}")
    
    # Lista de clientes
    clientes: List[Cliente] = [cliente1, cliente2, cliente3]
    print(f"\n--- Lista de clientes ({len(clientes)} registros) ---")
    for i, cliente in enumerate(clientes, 1):
        print(f"{i}. {cliente}")


if __name__ == "__main__":
    main()