
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Cliente:
    """
    Dataclass que representa un cliente de la empresa con métodos adicionales.
    
    Atributos:
        nombre: Nombre del cliente (persona o empresa)
        email: Dirección de correo electrónico
        pais: País donde se encuentra el cliente
        activo: Estado del cliente (True = activo, False = inactivo)
    """
    nombre: str
    email: str
    pais: str
    activo: bool = True
    
    def desactivar(self) -> None:
        """
        Cambia el estado del cliente a inactivo.
        Muestra un mensaje confirmando la desactivación.
        """
        if self.activo:
            self.activo = False
            print(f"Cliente '{self.nombre}' desactivado correctamente")
        else:
            print(f"El cliente '{self.nombre}' ya estaba desactivado")
    
    def activar(self) -> None:
        """
        Cambia el estado del cliente a activo.
        """
        if not self.activo:
            self.activo = True
            print(f"Cliente '{self.nombre}' activado correctamente")
        else:
            print(f"El cliente '{self.nombre}' ya estaba activo")
    
    def esta_activo(self) -> bool:
        """
        Verifica si el cliente está activo.
        
        Returns:
            True si el cliente está activo, False en caso contrario
        """
        return self.activo
    
    def __str__(self) -> str:
        """Representación en string del cliente."""
        estado = "ACTIVO" if self.activo else "INACTIVO"
        return f"Cliente: {self.nombre} ({self.email}) - {self.pais} - [{estado}]"


def main() -> None:
    """
    Función principal que demuestra el uso del método desactivar().
    """
    print("=== DEMOSTRACIÓN DEL MÉTODO DESACTIVAR() ===\n")
    
    # Crear un cliente activo
    cliente = Cliente(
        nombre="Empresa X",
        email="info@x.com",
        pais="España",
        activo=True
    )
    
    print("Estado inicial:")
    print(cliente)
    print(f"¿Está activo? {cliente.esta_activo()}")
    
    print("\n--- Desactivando cliente ---")
    cliente.desactivar()
    
    print("\nEstado después de desactivar:")
    print(cliente)
    print(f"¿Está activo? {cliente.esta_activo()}")
    
    print("\n--- Intentando desactivar nuevamente ---")
    cliente.desactivar()
    
    print("\n--- Activando cliente ---")
    cliente.activar()
    
    print("\nEstado final:")
    print(cliente)
    
    print("\n=== DEMOSTRACIÓN CON MÚLTIPLES CLIENTES ===\n")
    
    # Crear varios clientes
    clientes: List[Cliente] = [
        Cliente("Tech Solutions", "tech@sol.es", "España", True),
        Cliente("Global Inc.", "info@global.com", "USA", True),
        Cliente("Consultores Asociados", "contacto@casoc.es", "España", False)
    ]
    
    print("Clientes iniciales:")
    for c in clientes:
        print(f"  • {c}")
    
    print("\n--- Desactivando todos los clientes ---")
    for cliente in clientes:
        cliente.desactivar()
    
    print("\nClientes finales:")
    for c in clientes:
        print(f"  • {c}")


if __name__ == "__main__":
    main()