

from typing import Optional


class Producto:
    """
    Clase que representa un producto del inventario de la empresa.
    
    Atributos:
        nombre: Nombre del producto
        precio: Precio unitario del producto (en euros)
        stock: Cantidad disponible en inventario
    """
    
    def __init__(self, nombre: str, precio: float, stock: int) -> None:
        """
        Inicializa un nuevo producto.
        
        Args:
            nombre: Nombre del producto
            precio: Precio unitario (debe ser >= 0)
            stock: Cantidad inicial en stock (debe ser >= 0)
        """
        self.nombre: str = nombre
        self.precio: float = max(0.0, precio)  # Asegurar precio no negativo
        self._stock: int = max(0, stock)  # Encapsulación: stock como atributo "protegido"
    
    @property
    def stock(self) -> int:
        """Getter para el stock (lectura)."""
        return self._stock
    
    def vender(self, unidades: int) -> bool:
        """
        Vende una cantidad de unidades del producto.
        Reduce el stock si hay suficiente disponibilidad.
        
        Args:
            unidades: Número de unidades a vender
        
        Returns:
            True si la venta fue exitosa, False si no hay stock suficiente
        """
        if unidades <= 0:
            print(f"Error: Las unidades a vender deben ser positivas (solicitado: {unidades})")
            return False
        
        if unidades <= self._stock:
            self._stock -= unidades
            print(f"Venta realizada: {unidades} unidades de '{self.nombre}'")
            return True
        else:
            print(f"Error: Stock insuficiente de '{self.nombre}'. "
                  f"Disponible: {self._stock}, solicitado: {unidades}")
            return False
    
    def reponer(self, unidades: int) -> None:
        """
        Repone stock del producto.
        
        Args:
            unidades: Número de unidades a añadir al stock
        """
        if unidades <= 0:
            print(f"Error: Las unidades a reponer deben ser positivas (solicitado: {unidades})")
            return
        
        self._stock += unidades
        print(f"Reposición realizada: +{unidades} unidades de '{self.nombre}'")
    
    def valor_stock(self) -> float:
        """
        Calcula el valor total del stock actual.
        
        Returns:
            Valor total del stock (precio * cantidad)
        """
        return self.precio * self._stock
    
    def __str__(self) -> str:
        """Representación legible del producto."""
        return f"Producto: '{self.nombre}' | Precio: {self.precio:.2f} € | Stock: {self._stock} u."


def main() -> None:
    """
    Función principal que demuestra el uso de la clase Producto.
    """
    print("=== SISTEMA DE GESTIÓN DE PRODUCTOS ===\n")
    
    # Crear un producto
    producto = Producto("Portátil Gamer", 450.00, 50)
    
    print("Estado inicial:")
    print(producto)
    print(f"Valor del stock: {producto.valor_stock():.2f} €\n")
    
    # Vender unidades
    print("--- Realizando ventas ---")
    producto.vender(5)
    print(f"Stock restante: {producto.stock}  Valor del stock: {producto.valor_stock():.0f} €\n")
    
    # Intentar vender más de lo disponible
    print("--- Intento de venta excesiva ---")
    producto.vender(100)
    print(f"Stock restante: {producto.stock}\n")
    
    # Reponer stock
    print("--- Reposición de stock ---")
    producto.reponer(20)
    print(f"Stock restante: {producto.stock}  Valor del stock: {producto.valor_stock():.0f} €\n")
    
    # Venta adicional
    print("--- Venta adicional ---")
    producto.vender(10)
    print(f"Stock restante: {producto.stock}  Valor del stock: {producto.valor_stock():.0f} €")
    
    # Mostrar estado final
    print("\n--- Estado final ---")
    print(producto)
    
    print("\n=== DEMOSTRACIÓN CON MÚLTIPLES PRODUCTOS ===\n")
    
    # Inventario completo
    inventario = [
        Producto("Ratón USB", 25.50, 100),
        Producto("Teclado Mecánico", 89.99, 30),
        Producto("Monitor 24\"", 199.00, 15),
        Producto("Auriculares", 45.00, 50)
    ]
    
    print("Inventario inicial:")
    for p in inventario:
        print(f"  {p}")
    
    print("\n--- Simulación de ventas ---")
    inventario[0].vender(10)   # Vender 10 ratones
    inventario[2].vender(5)    # Vender 5 monitores
    
    print("\n--- Valor total del inventario ---")
    valor_total = sum(p.valor_stock() for p in inventario)
    for p in inventario:
        print(f"  {p.nombre}: {p.valor_stock():.2f} €")
    print(f"  TOTAL INVENTARIO: {valor_total:.2f} €")


if __name__ == "__main__":
    main()