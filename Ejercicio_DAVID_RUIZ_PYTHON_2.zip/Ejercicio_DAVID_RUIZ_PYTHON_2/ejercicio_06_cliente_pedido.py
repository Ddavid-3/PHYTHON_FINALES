

from dataclasses import dataclass
from typing import List


@dataclass
class Cliente:
    """Clase que representa un cliente."""
    nombre: str
    email: str


class Producto:
    """Clase que representa un producto con nombre y precio."""
    
    def __init__(self, nombre: str, precio: float) -> None:
        self.nombre: str = nombre
        self.precio: float = precio
    
    def __str__(self) -> str:
        return f"{self.nombre} ({self.precio:.2f} €)"


class Pedido:
    """
    Clase que representa un pedido realizado por un cliente.
    
    Atributos:
        cliente: Objeto Cliente que realiza el pedido
        productos: Lista de objetos Producto en el pedido
    """
    
    def __init__(self, cliente: Cliente, productos: List[Producto]) -> None:
        """
        Inicializa un nuevo pedido.
        
        Args:
            cliente: Cliente que realiza el pedido
            productos: Lista de productos solicitados
        """
        self.cliente: Cliente = cliente
        self.productos: List[Producto] = productos
    
    def total_pedido(self) -> float:
        """
        Calcula el total del pedido sumando los precios de todos los productos.
        
        Returns:
            Total del pedido en euros
        """
        return sum(producto.precio for producto in self.productos)
    
    def mostrar_resumen(self) -> None:
        """Muestra un resumen completo del pedido."""
        print(f"--- PEDIDO ---")
        print(f"Cliente: {self.cliente.nombre} ({self.cliente.email})")
        print("\nProductos:")
        for i, producto in enumerate(self.productos, 1):
            print(f"  {i}. {producto}")
        print(f"\nTotal del pedido: {self.total_pedido():.0f} €")


def main() -> None:
    """
    Función principal que demuestra la relación Cliente-Pedido.
    """
    # Crear un cliente
    cliente = Cliente(
        nombre="Empresa ABC",
        email="ventas@empresaabc.com"
    )
    
    # Crear productos
    productos: List[Producto] = [
        Producto("Portátil Gamer", 1200.00),
        Producto("Ratón Inalámbrico", 45.00),
        Producto("Teclado Mecánico", 95.00),
        Producto("Monitor 27\"", 350.00)
    ]
    
    # Crear pedido
    pedido = Pedido(cliente, productos)
    
    # Mostrar resumen y total
    pedido.mostrar_resumen()
    
    # Verificación de la salida esperada
    print(f"\n✓ Total del pedido: {pedido.total_pedido():.0f} €")


if __name__ == "__main__":
    main()