

import numpy as np


def main() -> None:
    """
    Función principal que analiza las ventas mensuales usando NumPy.
    """
    # Ventas mensuales de la empresa (en euros)
    # Meses: Ene, Feb, Mar, Abr, May, Jun, Jul, Ago, Sep, Oct, Nov, Dic
    ventas_mensuales: np.ndarray = np.array([
        12500,   # Enero
        14800,   # Febrero
        16700,   # Marzo
        15200,   # Abril
        18900,   # Mayo
        21000,   # Junio
        20500,   # Julio
        19800,   # Agosto
        17600,   # Septiembre
        18200,   # Octubre
        15300,   # Noviembre
        9800     # Diciembre
    ])
    
    # Nombres de los meses para referencia
    meses: list[str] = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
                        "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
    
    # Cálculos estadísticos con NumPy
    venta_media: float = np.mean(ventas_mensuales)
    venta_maxima: float = np.max(ventas_mensuales)
    venta_minima: float = np.min(ventas_mensuales)
    
    # Encontrar el mes de la venta máxima y mínima
    mes_max: str = meses[np.argmax(ventas_mensuales)]
    mes_min: str = meses[np.argmin(ventas_mensuales)]
    
    # Mostrar resultados
    print("=== ANÁLISIS DE VENTAS MENSUALES ===\n")
    
    # Tabla de ventas mensuales
    print("Ventas por mes:")
    for i, mes in enumerate(meses):
        print(f"  {mes}: {ventas_mensuales[i]:>6,.0f} €")
    
    print("\n--- Estadísticas ---")
    print(f"Venta media: {venta_media:.0f} €")
    print(f"Venta máxima: {venta_maxima:.0f} € (mes: {mes_max})")
    print(f"Venta mínima: {venta_minima:.0f} € (mes: {mes_min})")
    
    # Salida esperada (formato solicitado)
    print(f"\n✓ Venta media: {venta_media:.0f} € "
          f"Máxima: {venta_maxima:.0f} € "
          f"Mínima: {venta_minima:.0f} €")
    
    # Información adicional con NumPy
    print("\n--- Información adicional ---")
    print(f"Desviación estándar: {np.std(ventas_mensuales):.0f} €")
    print(f"Mediana: {np.median(ventas_mensuales):.0f} €")
    print(f"Rango: {np.ptp(ventas_mensuales):.0f} €")
    print(f"Suma total anual: {np.sum(ventas_mensuales):,.0f} €")


if __name__ == "__main__":
    main()