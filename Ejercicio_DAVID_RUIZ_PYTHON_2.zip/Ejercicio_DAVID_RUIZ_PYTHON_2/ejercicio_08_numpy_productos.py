
import numpy as np


def main() -> None:
    """
    Función principal que identifica el producto más vendido usando NumPy.
    """
    # Ventas de 3 productos (unidades vendidas)
    # Producto A, Producto B, Producto C
    ventas: np.ndarray = np.array([1250, 3200, 1875])
    
    # Nombres de los productos
    productos: list[str] = ["Producto A", "Producto B", "Producto C"]
    
    # Encontrar el índice del producto más vendido
    indice_max: int = np.argmax(ventas)
    producto_max: str = productos[indice_max]
    ventas_max: int = ventas[indice_max]
    
    # Encontrar el índice del producto menos vendido
    indice_min: int = np.argmin(ventas)
    producto_min: str = productos[indice_min]
    ventas_min: int = ventas[indice_min]
    
    # Mostrar resultados
    print("=== COMPARATIVA DE VENTAS POR PRODUCTO ===\n")
    
    # Tabla de ventas
    print("Ventas por producto:")
    for i, producto in enumerate(productos):
        print(f"  {producto}: {ventas[i]:>5,.0f} unidades")
    
    print(f"\n✓ Producto más vendido: {producto_max}")
    print(f"  (con {ventas_max:,} unidades vendidas)")
    
    print(f"\nProducto menos vendido: {producto_min}")
    print(f"  (con {ventas_min:,} unidades vendidas)")
    
    # Información adicional con NumPy
    print("\n--- Análisis adicional ---")
    print(f"Diferencia entre más y menos vendido: {ventas_max - ventas_min:,} unidades")
    print(f"Media de ventas: {np.mean(ventas):.0f} unidades")
    print(f"Venta total combinada: {np.sum(ventas):,} unidades")
    
    # Ordenar productos por ventas
    indices_ordenados = np.argsort(ventas)[::-1]  # Orden descendente
    print("\nRanking de productos:")
    for rank, idx in enumerate(indices_ordenados, 1):
        print(f"  {rank}º: {productos[idx]} ({ventas[idx]:,} unidades)")


if __name__ == "__main__":
    main()
