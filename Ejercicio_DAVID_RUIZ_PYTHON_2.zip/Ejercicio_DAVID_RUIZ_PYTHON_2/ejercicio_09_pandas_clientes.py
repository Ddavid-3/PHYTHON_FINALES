
import pandas as pd


def main() -> None:
    """
    Función principal que crea un DataFrame de clientes y filtra por país.
    """
    # Crear diccionario con los datos de clientes
    datos_clientes = {
        'nombre': ['Empresa A', 'Empresa B', 'Empresa C', 'Empresa D', 'Empresa E'],
        'país': ['España', 'Francia', 'España', 'Alemania', 'España'],
        'facturación_anual': [125000, 89000, 210000, 45000, 167000]
    }
    
    # Crear DataFrame
    df = pd.DataFrame(datos_clientes)
    
    # Mostrar DataFrame completo
    print("=== DATAFRAME DE CLIENTES ===\n")
    print(df.to_string(index=False))
    
    # Filtrar solo clientes de España
    clientes_espana = df[df['país'] == 'España']
    
    print("\n=== FILTRO: CLIENTES EN ESPAÑA ===\n")
    print(clientes_espana.to_string(index=False))
    
    # Extraer solo los nombres para la salida esperada
    nombres_espana = clientes_espana['nombre'].tolist()
    
    # Salida esperada (formato solicitado)
    print(f"\n✓ Clientes en España: {' '.join(nombres_espana)}")
    
    # Información adicional
    print(f"\n--- Estadísticas de clientes españoles ---")
    print(f"Número de clientes: {len(clientes_espana)}")
    print(f"Facturación total (España): {clientes_espana['facturación_anual'].sum():,.0f} €")
    print(f"Facturación media (España): {clientes_espana['facturación_anual'].mean():,.0f} €")
    
    # Demostrar filtros booleanos adicionales
    print("\n--- Otros filtros útiles ---")
    # Clientes con facturación > 100.000 €
    clientes_top = df[df['facturación_anual'] > 100000]
    print("Clientes con facturación > 100.000 €:")
    for _, row in clientes_top.iterrows():
        print(f"  • {row['nombre']} - {row['facturación_anual']:,} €")


if __name__ == "__main__":
    main()