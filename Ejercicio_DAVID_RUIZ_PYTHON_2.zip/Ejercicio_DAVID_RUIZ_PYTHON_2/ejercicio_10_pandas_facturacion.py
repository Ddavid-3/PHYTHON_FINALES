

import pandas as pd


def main() -> None:
    """
    Función principal que calcula facturación total y media de clientes.
    """
    # Crear diccionario con los datos de clientes
    datos_clientes = {
        'nombre': ['Empresa A', 'Empresa B', 'Empresa C'],
        'país': ['España', 'Francia', 'España'],
        'facturación_anual': [125000, 89000, 210000]
    }
    
    # Crear DataFrame
    df = pd.DataFrame(datos_clientes)
    
    # Mostrar DataFrame
    print("=== DATAFRAME DE CLIENTES ===\n")
    print(df.to_string(index=False))
    
    # Cálculos de facturación
    facturacion_total: float = df['facturación_anual'].sum()
    facturacion_media: float = df['facturación_anual'].mean()
    
    # Mostrar resultados
    print("\n=== ANÁLISIS DE FACTURACIÓN ===\n")
    print(f"Facturación total: {facturacion_total:,.0f} €")
    print(f"Facturación media: {facturacion_media:,.2f} €")
    
    # Salida esperada (formato solicitado)
    print(f"\n✓ Facturación total: {facturacion_total:.0f} € Media: {facturacion_media:.2f} €")
    
    # Información adicional con pandas
    print("\n--- Desglose por país ---")
    facturacion_pais = df.groupby('país')['facturación_anual'].agg(['sum', 'mean', 'count'])
    print(facturacion_pais.round(2))
    
    print("\n--- Estadísticas completas ---")
    estadisticas = df['facturación_anual'].describe()
    print(f"  Mínimo: {estadisticas['min']:,.0f} €")
    print(f"  Máximo: {estadisticas['max']:,.0f} €")
    print(f"  Mediana: {estadisticas['50%']:,.0f} €")
    print(f"  Desviación estándar: {estadisticas['std']:,.0f} €")
    
    # Demostrar diferentes formas de calcular
    print("\n--- Métodos alternativos de cálculo ---")
    print(f"Suma (con sum()): {df['facturación_anual'].sum():,.0f} €")
    print(f"Suma (con valores): {sum(df['facturación_anual']):,.0f} €")
    print(f"Media (con mean()): {df['facturación_anual'].mean():,.0f} €")
    print(f"Media (manual): {df['facturación_anual'].sum() / len(df):,.0f} €")


if __name__ == "__main__":
    main()