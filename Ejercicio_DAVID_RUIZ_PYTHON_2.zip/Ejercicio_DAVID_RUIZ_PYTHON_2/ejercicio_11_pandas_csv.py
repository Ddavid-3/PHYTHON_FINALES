
import pandas as pd
import os


def crear_csv_ejemplo() -> str:
    """
    Crea un archivo CSV de ejemplo con productos.
    
    Returns:
        Nombre del archivo creado
    """
    # Datos de ejemplo (simulando exportación de Odoo)
    datos = {
        'id': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'nombre': [
            'Portátil Gamer', 'Ratón USB', 'Teclado Mecánico', 'Monitor 24"',
            'Auriculares', 'Webcam 4K', 'Altavoces', 'Silla Ergonómica',
            'Disco SSD 1TB', 'Tarjeta Gráfica'
        ],
        'precio': [899.99, 25.50, 89.99, 199.00, 45.00, 79.99, 59.99, 249.00, 89.99, 450.00],
        'categoria': ['Electrónica', 'Periféricos', 'Periféricos', 'Monitores', 
                     'Audio', 'Periféricos', 'Audio', 'Mobiliario', 'Almacenamiento', 'Componentes'],
        'stock': [15, 150, 45, 22, 80, 12, 35, 8, 60, 5]
    }
    
    df = pd.DataFrame(datos)
    archivo = "productos_odoo.csv"
    df.to_csv(archivo, index=False, encoding='utf-8')
    print(f"Archivo CSV de ejemplo creado: {archivo}")
    return archivo


def main() -> None:
    """
    Función principal que carga el CSV y calcula estadísticas.
    """
    # Crear archivo CSV de ejemplo si no existe
    archivo_csv = "productos_odoo.csv"
    if not os.path.exists(archivo_csv):
        archivo_csv = crear_csv_ejemplo()
    
    # Cargar CSV con pandas
    print(f"Cargando archivo: {archivo_csv}")
    df_productos = pd.read_csv(archivo_csv)
    
    # Mostrar primeras filas
    print("\n=== VISTA PREVIA DEL CSV ===\n")
    print(df_productos.head(10).to_string(index=False))
    
    # Calcular estadísticas
    total_productos: int = len(df_productos)
    precio_medio: float = df_productos['precio'].mean()
    
    # Salida esperada
    print("\n=== RESULTADOS ===\n")
    print(f"Productos: {total_productos}")
    print(f"Precio medio: {precio_medio:.2f} €")
    
    # Información adicional
    print("\n--- Información del DataFrame ---")
    print(f"Columnas: {list(df_productos.columns)}")
    print(f"Tipos de datos:\n{df_productos.dtypes}")
    print(f"\nEstadísticas de precios:")
    print(f"  Mínimo: {df_productos['precio'].min():.2f} €")
    print(f"  Máximo: {df_productos['precio'].max():.2f} €")
    print(f"  Mediana: {df_productos['precio'].median():.2f} €")
    
    # Limpiar archivo temporal (opcional)
    # os.remove(archivo_csv)  # Descomentar para eliminar el archivo después


if __name__ == "__main__":
    main()