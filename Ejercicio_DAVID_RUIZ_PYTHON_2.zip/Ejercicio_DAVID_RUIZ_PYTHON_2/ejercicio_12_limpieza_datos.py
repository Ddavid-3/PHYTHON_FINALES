

import pandas as pd
import numpy as np


def main() -> None:
    """
    Función principal que demuestra la limpieza de datos con dropna().
    """
    # Crear DataFrame con datos de productos (incluyendo NaN)
    datos = {
        'id': [1, 2, 3, 4, 5, 6, 7, 8],
        'nombre': [
            'Portátil Gamer', 'Ratón USB', 'Teclado Mecánico', 'Monitor 24"',
            'Auriculares', 'Webcam 4K', 'Altavoces', 'Silla Ergonómica'
        ],
        'precio': [899.99, 25.50, np.nan, 199.00, 45.00, np.nan, 59.99, np.nan],
        'categoria': ['Electrónica', 'Periféricos', 'Periféricos', 'Monitores', 
                     'Audio', 'Periféricos', 'Audio', 'Mobiliario'],
        'stock': [15, 150, 45, 22, 80, 12, 35, 8]
    }
    
    df = pd.DataFrame(datos)
    
    print("=== DATAFRAME ORIGINAL ===\n")
    print(df.to_string(index=False))
    print(f"\nRegistros totales: {len(df)}")
    
    # Mostrar valores nulos
    print("\n--- Valores nulos por columna ---")
    print(df.isnull().sum())
    
    # Mostrar productos con precio nulo
    productos_sin_precio = df[df['precio'].isna()]
    print(f"\nProductos con precio NaN:")
    for _, row in productos_sin_precio.iterrows():
        print(f"  • {row['nombre']} (ID: {row['id']})")
    
    # Eliminar filas con precio NaN
    registros_iniciales = len(df)
    df_limpio = df.dropna(subset=['precio'])  # Elimina solo donde precio es NaN
    registros_eliminados = registros_iniciales - len(df_limpio)
    
    print(f"\n=== DESPUÉS DE LIMPIEZA ===\n")
    print(f"Registros eliminados: {registros_eliminados}")
    print(f"Registros restantes: {len(df_limpio)}")
    
    print("\n--- DATAFRAME LIMPIO ---")
    print(df_limpio.to_string(index=False))
    
    # Mostrar estadísticas después de limpiar
    print(f"\nPrecio medio después de limpieza: {df_limpio['precio'].mean():.2f} €")
    
    # Métodos alternativos de limpieza
    print("\n--- Otros métodos de limpieza ---")
    
    # Eliminar filas con cualquier NaN
    df_sin_ningun_nan = df.dropna()
    print(f"Eliminando filas con cualquier NaN: {len(df) - len(df_sin_ningun_nan)} eliminados")
    
    # Rellenar NaN con un valor
    df_rellenado = df.fillna({'precio': 0})
    print(f"Rellenando NaN con 0: {df_rellenado['precio'].isna().sum()} NaN restantes")
    
    # Eliminar solo si todos los valores son NaN
    print("\n--- Información de la limpieza principal ---")
    print(f"✓ Registros eliminados: {registros_eliminados}")


if __name__ == "__main__":
    main()