

import matplotlib.pyplot as plt
import numpy as np

# Configurar matplotlib para mostrar gráficos (en algunos entornos es necesario)
plt.rcParams['figure.figsize'] = (12, 6)
plt.rcParams['font.size'] = 10


def main() -> None:
    """
    Función principal que crea la gráfica de evolución de ventas.
    """
    # Datos de ventas mensuales
    meses = [
        'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ]
    
    ventas = [12000, 13500, 14200, 15000, 14800, 15500, 
              16000, 15800, 16200, 17000, 17500, 19000]
    
    # Crear la figura y los ejes
    fig, ax = plt.subplots()
    
    # Dibujar gráfica de líneas
    ax.plot(meses, ventas, marker='o', linewidth=2, markersize=8, 
            color='#2E86AB', markerfacecolor='#A23B72', markeredgecolor='#2E86AB')
    
    # Añadir título
    ax.set_title('Evolución de Ventas Mensuales - Último Año', 
                 fontsize=14, fontweight='bold', pad=20)
    
    # Etiquetas de los ejes
    ax.set_xlabel('Mes', fontsize=12, fontweight='bold')
    ax.set_ylabel('Ventas (€)', fontsize=12, fontweight='bold')
    
    # Añadir rejilla
    ax.grid(True, linestyle='--', alpha=0.7, color='gray')
    
    # Rotar etiquetas del eje X para mejor legibilidad
    plt.xticks(rotation=45, ha='right')
    
    # Ajustar límites del eje Y
    ax.set_ylim(min(ventas) - 2000, max(ventas) + 2000)
    
    # Añadir valor encima de cada punto
    for i, (mes, venta) in enumerate(zip(meses, ventas)):
        ax.annotate(f'{venta:,.0f} €', 
                   xy=(i, venta), 
                   xytext=(0, 10), 
                   textcoords='offset points',
                   ha='center',
                   fontsize=9,
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.7))
    
    # Añadir línea de tendencia
    x_numeric = np.arange(len(meses))
    z = np.polyfit(x_numeric, ventas, 1)
    p = np.poly1d(z)
    ax.plot(meses, p(x_numeric), '--', color='red', alpha=0.5, 
            label=f'Tendencia (pendiente: {z[0]:.0f} €/mes)')
    ax.legend(loc='upper left')
    
    # Colorear área bajo la curva
    ax.fill_between(x_numeric, ventas, alpha=0.1, color='#2E86AB')
    
    # Destacar el punto máximo
    max_venta = max(ventas)
    max_mes = meses[ventas.index(max_venta)]
    ax.scatter(ventas.index(max_venta), max_venta, color='red', s=200, zorder=5, 
               marker='*', label=f'Máximo: {max_venta:,.0f} €')
    ax.legend(loc='upper left')
    
    # Añadir anotación del crecimiento total
    crecimiento = ventas[-1] - ventas[0]
    crecimiento_pct = (crecimiento / ventas[0]) * 100
    ax.text(0.02, 0.95, f'Crecimiento anual: {crecimiento:,.0f} € ({crecimiento_pct:.1f}%)',
            transform=ax.transAxes, fontsize=10,
            bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.8))
    
    # Ajustar layout
    plt.tight_layout()
    
    # Mostrar el gráfico
    plt.show()
    
    # Mostrar estadísticas en consola
    print("=== ANÁLISIS DE VENTAS ===\n")
    print(f"Venta media mensual: {np.mean(ventas):,.0f} €")
    print(f"Venta máxima: {max(ventas):,.0f} € ({max_mes})")
    print(f"Venta mínima: {min(ventas):,.0f} € ({meses[ventas.index(min(ventas))]})")
    print(f"Crecimiento total: {crecimiento:,.0f} €")
    print(f"Crecimiento porcentual: {crecimiento_pct:.1f}%")


if __name__ == "__main__":
    main()