

import matplotlib.pyplot as plt
import numpy as np

# Configurar matplotlib
plt.rcParams['figure.figsize'] = (10, 6)


def main() -> None:
    """
    Función principal que crea la gráfica de barras de ventas por producto.
    """
    # Datos de ventas por producto
    productos = ['Producto A', 'Producto B', 'Producto C', 'Producto D']
    ventas = [52000, 68000, 45000, 73000]
    
    # Colores para las barras
    colores = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
    
    # Crear la figura y los ejes
    fig, ax = plt.subplots()
    
    # Crear gráfica de barras
    barras = ax.bar(productos, ventas, color=colores, edgecolor='black', linewidth=1.5)
    
    # Añadir título
    ax.set_title('Comparativa de Ventas Anuales por Producto', 
                 fontsize=14, fontweight='bold', pad=20)
    
    # Etiquetas de los ejes
    ax.set_xlabel('Producto', fontsize=12, fontweight='bold')
    ax.set_ylabel('Ventas (€)', fontsize=12, fontweight='bold')
    
    # Añadir rejilla en el eje Y
    ax.grid(True, axis='y', linestyle='--', alpha=0.7)
    
    # Añadir el valor exacto encima de cada barra
    for barra, venta in zip(barras, ventas):
        altura = barra.get_height()
        ax.text(barra.get_x() + barra.get_width()/2., altura + 1000,
                f'{venta:,.0f} €',
                ha='center', va='bottom', fontsize=11, fontweight='bold')
    
    # Destacar el producto más vendido
    max_venta = max(ventas)
    max_index = ventas.index(max_venta)
    barras[max_index].set_color('#FF4444')
    barras[max_index].set_edgecolor('darkred')
    barras[max_index].set_linewidth(2)
    
    # Añadir anotación del producto más vendido
    ax.text(max_index, max_venta + 3000, '⭐ ¡Más vendido!',
            ha='center', fontsize=10, color='darkred', fontweight='bold',
            bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.8))
    
    # Añadir línea de referencia de media
    media = np.mean(ventas)
    ax.axhline(y=media, color='blue', linestyle='--', linewidth=2, 
               label=f'Media: {media:,.0f} €')
    ax.legend(loc='upper right')
    
    # Ajustar límites del eje Y
    ax.set_ylim(0, max_ventas + 10000)
    
    # Añadir valores porcentuales encima de cada barra
    for i, (barra, venta) in enumerate(zip(barras, ventas)):
        porcentaje = (venta / sum(ventas)) * 100
        ax.text(barra.get_x() + barra.get_width()/2., barra.get_height() - 2000,
                f'{porcentaje:.1f}%',
                ha='center', va='top', fontsize=9, color='white', fontweight='bold')
    
    # Añadir información adicional en el gráfico
    texto_info = f"Venta total: {sum(ventas):,.0f} €\nMedia: {media:,.0f} €\nMáx: {max_venta:,.0f} €"
    ax.text(0.98, 0.98, texto_info, transform=ax.transAxes, 
            verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8),
            fontsize=9)
    
    # Ajustar layout
    plt.tight_layout()
    
    # Mostrar el gráfico
    plt.show()
    
    # Mostrar estadísticas en consola
    print("=== ANÁLISIS DE VENTAS POR PRODUCTO ===\n")
    for producto, venta in zip(productos, ventas):
        print(f"{producto}: {venta:,.0f} €")
    
    print(f"\nProducto más vendido: {productos[max_index]} ({max_venta:,.0f} €)")
    print(f"Venta total: {sum(ventas):,.0f} €")
    print(f"Venta media: {media:,.0f} €")
    print(f"Diferencia entre máximo y mínimo: {max_venta - min(ventas):,.0f} €")


if __name__ == "__main__":
    main()