

import numpy as np
from tensorflow import keras
from tensorflow.keras import layers
import warnings
warnings.filterwarnings('ignore')


def preparar_datos(ventas: list) -> tuple:
    """
    Prepara los datos para entrenamiento (predicción del siguiente valor).
    
    Args:
        ventas: Lista de ventas mensuales
    
    Returns:
        Tupla con (X, y) para entrenamiento
    """
    X = []
    y = []
    
    # Usar cada valor para predecir el siguiente
    for i in range(len(ventas) - 1):
        X.append([ventas[i]])
        y.append(ventas[i + 1])
    
    X = np.array(X)
    y = np.array(y)
    
    # Normalizar datos
    media_X = np.mean(X)
    std_X = np.std(X)
    media_y = np.mean(y)
    std_y = np.std(y)
    
    X_normalizado = (X - media_X) / std_X
    y_normalizado = (y - media_y) / std_y
    
    return X_normalizado, y_normalizado, media_X, std_X, media_y, std_y


def crear_modelo() -> keras.Model:
    """
    Crea un modelo neuronal sencillo con una capa oculta.
    
    Returns:
        Modelo de Keras compilado
    """
    model = keras.Sequential([
        layers.Input(shape=(1,)),
        layers.Dense(8, activation='relu'),  # Capa oculta con 8 neuronas
        layers.Dense(1)  # Capa de salida
    ])
    
    model.compile(
        optimizer='adam',
        loss='mse',
        metrics=['mae']
    )
    
    return model


def main() -> None:
    """
    Función principal que entrena el modelo y realiza predicciones.
    """
    # Ventas mensuales del último año
    ventas = [12000, 13500, 14200, 15000, 14800, 15500, 
              16000, 15800, 16200, 17000, 17500, 19000]
    
    print("=== PREDICCIÓN DE VENTAS CON KERAS ===\n")
    print(f"Datos de entrenamiento (últimos 12 meses):")
    meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 
             'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic']
    for mes, venta in zip(meses, ventas):
        print(f"  {mes}: {venta:,} €")
    
    # Preparar datos
    X, y, media_X, std_X, media_y, std_y = preparar_datos(ventas)
    
    print(f"\nDatos preparados: {len(X)} muestras de entrenamiento")
    print(f"Forma de X: {X.shape}")
    
    # Crear y entrenar modelo
    model = crear_modelo()
    
    print("\n--- Entrenando modelo ---")
    history = model.fit(
        X, y,
        epochs=200,  # Entrenar por 200 épocas
        verbose=0,   # Silencioso
        validation_split=0.2  # Usar 20% para validación
    )
    
    # Mostrar pérdida final
    print(f"Pérdida final (MSE): {history.history['loss'][-1]:.4f}")
    print(f"MAE final: {history.history['mae'][-1]:.4f}")
    
    # Predecir el próximo mes (basado en la última venta)
    ultima_venta = ventas[-1]
    ultima_venta_normalizada = (np.array([[ultima_venta]]) - media_X) / std_X
    
    prediccion_normalizada = model.predict(ultima_venta_normalizada, verbose=0)
    prediccion = prediccion_normalizada[0][0] * std_y + media_y
    
    print(f"\n--- Predicción ---")
    print(f"Última venta registrada (Diciembre): {ultima_venta:,} €")
    print(f"Predicción de ventas para el próximo mes (Enero): {prediccion:.0f} €")
    
    # Salida esperada (formato solicitado)
    print(f"\n✓ Predicción de ventas para el próximo mes: {prediccion:.0f} €")
    
    # Mostrar evolución del entrenamiento
    print("\n--- Evolución del entrenamiento ---")
    print(f"Épocas entrenadas: {len(history.history['loss'])}")
    print(f"Pérdida inicial: {history.history['loss'][0]:.4f}")
    print(f"Pérdida final: {history.history['loss'][-1]:.4f}")
    print(f"Mejora: {(history.history['loss'][0] - history.history['loss'][-1]):.4f}")
    
    # También predecir los próximos 3 meses
    print("\n--- Predicciones extendidas ---")
    predicciones = [ultima_venta]
    for i in range(3):
        entrada = np.array([[predicciones[-1]]])
        entrada_norm = (entrada - media_X) / std_X
        pred_norm = model.predict(entrada_norm, verbose=0)
        pred = pred_norm[0][0] * std_y + media_y
        predicciones.append(pred)
        nombre_mes = ['Enero', 'Febrero', 'Marzo'][i]
        print(f"  {nombre_mes}: {pred:.0f} €")


if __name__ == "__main__":
    main()