
import empresa_constantes as ec


def calcular_factura(base_imponible: float, iva_porcentaje: float) -> dict:
    """
    Calcula el total de una factura aplicando el IVA.
    
    Args:
        base_imponible: Importe base sin IVA
        iva_porcentaje: Porcentaje de IVA a aplicar
    
    Returns:
        Diccionario con los resultados del cálculo
    """
    iva: float = base_imponible * (iva_porcentaje / 100)
    total: float = base_imponible + iva
    
    return {
        "base": base_imponible,
        "iva_porcentaje": iva_porcentaje,
        "iva": iva,
        "total": total
    }


def main() -> None:
    """
    Función principal que demuestra el uso del módulo de constantes.
    """
    # Datos de ejemplo
    base_imponible: float = 100.00
    iva_aplicado: float = ec.TIPOS_IVA[2]  # 21%
    
    # Realizar cálculo
    resultado = calcular_factura(base_imponible, iva_aplicado)
    
    # Mostrar resultados usando las constantes del módulo
    print(f"Base: {ec.formatear_importe(resultado['base'])}")
    print(f"IVA ({resultado['iva_porcentaje']:.0f}%): {ec.formatear_importe(resultado['iva'])}")
    print(f"Total: {ec.formatear_importe(resultado['total'])}")
    
    # Información adicional
    print(f"\n--- Información adicional ---")
    print(f"Moneda por defecto: {ec.MONEDA_POR_DEFECTO}")
    print(f"Tipos de IVA disponibles: {ec.TIPOS_IVA}")
    print(f"Estados de factura: {ec.ESTADOS_FACTURA}")


if __name__ == "__main__":
    main()