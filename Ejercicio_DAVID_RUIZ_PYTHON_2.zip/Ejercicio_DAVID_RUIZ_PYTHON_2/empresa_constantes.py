
from typing import Dict, Tuple

# Tipos de IVA disponibles (porcentaje)
TIPOS_IVA: Tuple[float, float, float] = (0.0, 10.0, 21.0)

# Diccionario con nombres descriptivos de los tipos de IVA
TIPOS_IVA_NOMBRES: Dict[float, str] = {
    0.0: "Superreducido",
    10.0: "Reducido",
    21.0: "General"
}

# Estados de una factura
ESTADO_BORRADOR: str = "BORRADOR"
ESTADO_CONFIRMADA: str = "CONFIRMADA"
ESTADO_PAGADA: str = "PAGADA"

# Lista de todos los estados para validaciones
ESTADOS_FACTURA: Tuple[str, str, str] = (
    ESTADO_BORRADOR,
    ESTADO_CONFIRMADA,
    ESTADO_PAGADA
)

# Moneda por defecto
MONEDA_POR_DEFECTO: str = "€"

# Formato de moneda
FORMATO_MONEDA: str = "{:.2f} {}"


def formatear_importe(importe: float, moneda: str = MONEDA_POR_DEFECTO) -> str:
    """
    Formatea un importe con la moneda especificada.
    
    Args:
        importe: Cantidad a formatear
        moneda: Símbolo de la moneda
    
    Returns:
        String formateado (ej: "100.00 €")
    """
    return FORMATO_MONEDA.format(importe, moneda)