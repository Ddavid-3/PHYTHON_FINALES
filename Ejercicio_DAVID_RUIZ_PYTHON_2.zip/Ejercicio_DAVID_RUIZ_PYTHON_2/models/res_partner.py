

import logging
from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class ResPartnerInherit(models.Model):
    """
    Herencia del modelo res.partner para sobrescribir el método create().
    """
    _inherit = 'res.partner'
    
    # Se puede añadir un campo adicional para demostrar la herencia
    custom_created = fields.Boolean(
        string="Creado con proceso especial",
        default=False,
        readonly=True
    )
    
   