

from odoo import api, fields, models


class SaleOrderInherit(models.Model):
    """
    Herencia del modelo sale.order para añadir campo calculado.
    """
    _inherit = 'sale.order'
    
    # Campo calculado (no almacenado en BD)
    amount_total_with_tax = fields.Float(
        string="Total con IVA",
        compute="_compute_amount_total_with_tax",
        help="Total del pedido con IVA incluido (calculado automáticamente)"
    )
    
    @api.depends('amount_untaxed', 'amount_tax')
    def _compute_amount_total_with_tax(self):
        """
        Calcula el total con IVA como la suma de base imponible e impuestos.
        Se actualiza automáticamente al cambiar líneas del pedido.
        """
        for order in self:
            order.amount_total_with_tax = order.amount_untaxed + order.amount_tax
