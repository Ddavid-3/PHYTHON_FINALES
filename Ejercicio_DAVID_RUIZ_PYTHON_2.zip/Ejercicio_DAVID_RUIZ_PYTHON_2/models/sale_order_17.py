"""
Módulo personalizado de Odoo 16 - models/sale_order.py
Añade campo booleano reviewed y método con logging.
"""

import logging
from odoo import api, fields, models

# Configurar logger del módulo
_logger = logging.getLogger(__name__)


class SaleOrderInherit(models.Model):
    """
    Herencia del modelo sale.order para añadir campo reviewed y método.
    """
    _inherit = 'sale.order'
    
    # Campo booleano para marcar pedido como revisado
    reviewed = fields.Boolean(
        string="Revisado por Administración",
        default=False,
        help="Indica si el pedido ha sido revisado por el equipo de administración"
    )
    
    def action_mark_reviewed(self):
        """
        Marca el pedido como revisado y escribe un mensaje en el log.
        Este método se ejecuta desde un botón en la vista del formulario.
        """
        for order in self:
            # Marcar como revisado
            order.reviewed = True
            
            # Obtener nombre del usuario actual
            user_name = self.env.user.name
            user_login = self.env.user.login
            
            # Mensaje en el log del servidor
            _logger.info(f"Pedido {order.name} marcado como revisado por el usuario {user_name} ({user_login})")
            
            # También se puede añadir un mensaje en el chatter del pedido
            order.message_post(
                body=f"✅ Pedido marcado como revisado por {user_name}",
                subject="Revisión administrativa"
            )
        
        return True
    
    def action_mark_unreviewed(self):
        """
        Método adicional para desmarcar la revisión (opcional).
        """
        for order in self:
            order.reviewed = False
            
            user_name = self.env.user.name
            _logger.info(f"Pedido {order.name} desmarcado como revisado por {user_name}")
            
            order.message_post(
                body=f"⚠️ Revisión desmarcada por {user_name}",
                subject="Revisión administrativa"
            )
        
        return True